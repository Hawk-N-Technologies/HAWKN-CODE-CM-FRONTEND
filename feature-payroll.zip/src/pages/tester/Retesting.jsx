import { useState } from "react";
import Badge from "../../components/common/Badge";
import Button from "../../components/common/Button";
import Select from "../../components/common/Select";
import Textarea from "../../components/common/TextArea";
import { showToast } from "../../components/common/Toast";
export default function Retesting() {
  const [data, setData] = useState([
    ["BUG-003", "Validation message", "v1.4.2", "Pending", ""],
    ["BUG-005", "Login timeout", "v1.4.2", "Passed", "Verified after fix."],
  ]);
  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-xl font-bold text-cm-text">Retesting</h1>
        <p className="mt-1 text-sm text-cm-text-muted">
          Verify fixes for bugs returned for retesting.
        </p>
      </div>
      {data.map((x) => (
        <section
          key={x[0]}
          className="rounded-cm-lg border border-cm-border bg-cm-card p-5 shadow-sm"
        >
          <div className="flex justify-between">
            <div>
              <p className="text-xs text-cm-text-muted">
                {x[0]} · {x[2]}
              </p>
              <h2 className="font-semibold text-cm-text">{x[1]}</h2>
            </div>
            <Badge tone={x[3] === "Passed" ? "success" : "warning"}>
              {x[3]}
            </Badge>
          </div>
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            <Select
              label="Retest Result"
              value={x[3]}
              options={["Pending", "Passed", "Failed"].map((v) => ({
                value: v,
                label: v,
              }))}
              onChange={(e) =>
                setData((p) =>
                  p.map((y) =>
                    y[0] === x[0]
                      ? [y[0], y[1], y[2], e.target.value, y[4]]
                      : y,
                  ),
                )
              }
            />
            <Textarea
              label="Retest Notes"
              value={x[4]}
              onChange={(e) =>
                setData((p) =>
                  p.map((y) =>
                    y[0] === x[0]
                      ? [y[0], y[1], y[2], y[3], e.target.value]
                      : y,
                  ),
                )
              }
            />
          </div>
          <div className="mt-4 flex justify-end">
            <Button
              size="sm"
              onClick={() => showToast.success("Retest result saved.")}
            >
              Save Retest
            </Button>
          </div>
        </section>
      ))}
    </div>
  );
}
